using System.Collections;
using UnityEngine;

public class ShootingMechanism : MonoBehaviour
{
    public GameObject bulletPrefab; // 총알 프리팹
    public Transform firePoint; // 총알이 발사되는 위치
    public Transform player; // 플레이어의 Transform을 참조
    public float minRestTime = 1f;
    public float maxRestTime = 3f;
    public int minBulletCount = 1;
    public int maxBulletCount = 5;
    public float bulletSpeed = 5f;

    private void Start()
    {
        StartCoroutine(ShootingRoutine());
    }

    private IEnumerator ShootingRoutine()
    {
        while (true)
        {
            // 랜덤한 시간 동안 쉬기
            float restTime = Random.Range(minRestTime, maxRestTime);
            yield return new WaitForSeconds(restTime);

            // 랜덤한 숫자의 총알 발사
            int bulletCount = Random.Range(minBulletCount, maxBulletCount);

            for (int i = 0; i < bulletCount; i++)
            {
                ShootBullet();
                yield return new WaitForSeconds(0.2f); // 0.2초 간격으로 총알 발사
            }
        }
    }

    private void ShootBullet()
    {
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        bullet.transform.localScale *= 1.5f; // 총알 크기를 1.5배로
        Vector2 direction = (player.position - firePoint.position).normalized;
        bullet.GetComponent<Rigidbody2D>().velocity = direction * bulletSpeed;
    }
}
