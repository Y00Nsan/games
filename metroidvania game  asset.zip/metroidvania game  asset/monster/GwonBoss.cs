using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossController : MonoBehaviour
{
    public GameObject prefab;
    public int numberOfPrefabs = 4;
    public float spacing = 1.0f;
    private GameObject[] prefabs;
    private bool isFacingRight = true;
    private Vector3 previousPosition;

    public float minTime;
    public float maxTime;
    public float moveSpeed;
    public Transform[] movePoints;
    private Transform targetPoint;
    private float timer;
    private Animator animator;

    public float dashSpeed; // Speed of the dash
    public float dashTime = 3.0f; // Duration of the dash
    private float dashTimer; // Timer for the dash duration
    private bool isDashing = false; // To check if the boss is dashing
    private Vector2 dashTargetPosition; // Position to dash towards

    private float standStillTimer = 1.0f; // Time to stand still before dashing
    private bool isStandingStill = false; // To check if the boss is standing still before dashing

    public EnemyHealth enemyHealth; // Reference to the EnemyHealth script
    public ShootingMechanism shootingMechanism; // Reference to the ShootingMechanism script

    private bool enraged = false;

    void Start()
    {
        animator = GetComponent<Animator>();
        prefabs = new GameObject[numberOfPrefabs];

        for (int i = 0; i < numberOfPrefabs; i++)
        {
            Vector3 position = transform.position + new Vector3((i + 1) * spacing, 0, 0);
            prefabs[i] = Instantiate(prefab, position, Quaternion.identity);
        }

        previousPosition = transform.position;

        // Initialize timer and set a random target point
        timer = Random.Range(minTime, maxTime);
        SetRandomTargetPoint();
    }

    void Update()
    {
        if (enemyHealth.currentHealth <= enemyHealth.maxHealth * 0.2f && !enraged)
        {
            Enrage();
        }

        if (isDashing)
        {
            HandleDashing();
        }
        else if (isStandingStill)
        {
            HandleStandingStill();
        }
        else
        {
            // Check if the boss has changed direction
            Vector3 currentPosition = transform.position;
            if (currentPosition.x > previousPosition.x && isFacingRight)
            {
                Flip(false); // moving left
            }
            else if (currentPosition.x < previousPosition.x && !isFacingRight)
            {
                Flip(true); // moving right
            }
            previousPosition = currentPosition;

            // Make the prefabs follow the boss like a snake
            for (int i = 0; i < numberOfPrefabs; i++)
            {
                Vector3 targetPosition = (i == 0) ? transform.position : prefabs[i - 1].transform.position;
                prefabs[i].transform.position = Vector3.Lerp(prefabs[i].transform.position, targetPosition, Time.deltaTime * 5);
            }

            // Handle idle behavior
            if (timer <= 0)
            {
                StartStandingStill();
            }
            else
            {
                timer -= Time.deltaTime;
                MoveTowardsTargetPoint();
            }
        }
    }

    private void MoveTowardsTargetPoint()
    {
        if (targetPoint != null)
        {
            Vector3 direction = (targetPoint.position - transform.position).normalized;
            transform.position += direction * moveSpeed * Time.deltaTime;

            // Check if the character is close to the target point
            if (Vector3.Distance(transform.position, targetPoint.position) < 0.1f)
            {
                SetRandomTargetPoint();
            }
        }
    }

    private void SetRandomTargetPoint()
    {
        if (movePoints.Length > 0)
        {
            targetPoint = movePoints[Random.Range(0, movePoints.Length)];
        }
    }

    private void StartStandingStill()
    {
        animator.SetBool("isRunning", true);
        isStandingStill = true;
        standStillTimer = 1.0f;
    }

    private void HandleStandingStill()
    {
        standStillTimer -= Time.deltaTime;
        if (standStillTimer <= 0)
        {
            StartDashing();
            isStandingStill = false;
        }
        else
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                if (player.transform.position.x > transform.position.x && isFacingRight)
                {
                    Flip(false); // Player is on the left
                }
                else if (player.transform.position.x < transform.position.x && !isFacingRight)
                {
                    Flip(true); // Player is on the right
                }
            }
        }
    }

    private void StartDashing()
    {
        dashTimer = dashTime;
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            dashTargetPosition = player.transform.position;
            isDashing = true;
        }
        else
        {
            Debug.LogWarning("Player not found!");
        }
    }

    private void HandleDashing()
    {
        dashTimer -= Time.deltaTime;
        if (dashTimer <= 0)
        {
            animator.SetBool("isRunning", false);
            isDashing = false;
            timer = Random.Range(minTime, maxTime);
        }
        else
        {
            Vector2 direction = (dashTargetPosition - (Vector2)transform.position).normalized;
            Vector2 movement = direction * dashSpeed * Time.deltaTime;
            transform.position = (Vector2)transform.position + movement;
        }
    }

    private void Enrage()
    {
        enraged = true;
        moveSpeed = 12;
        dashTime *= 1.2f;
        shootingMechanism.minRestTime = 2;
        shootingMechanism.maxRestTime = 5;
        shootingMechanism.minBulletCount = 7;
        shootingMechanism.maxBulletCount = 12;

        // Trigger the "Stage2" animation
        animator.SetTrigger("Stage2");
        animator.SetBool("isRunning", true);
    }

    void Flip(bool faceRight)
    {
        isFacingRight = faceRight;
        Vector3 theScale = transform.localScale;
        theScale.x = faceRight ? Mathf.Abs(theScale.x) : -Mathf.Abs(theScale.x);
        transform.localScale = theScale;

        foreach (GameObject prefab in prefabs)
        {
            Vector3 prefabScale = prefab.transform.localScale;
            prefabScale.x = faceRight ? Mathf.Abs(prefabScale.x) : -Mathf.Abs(prefabScale.x);
            prefab.transform.localScale = prefabScale;
        }
    }

    void OnDestroy()
    {
        foreach (GameObject prefab in prefabs)
        {
            Destroy(prefab);
        }
    }
}
